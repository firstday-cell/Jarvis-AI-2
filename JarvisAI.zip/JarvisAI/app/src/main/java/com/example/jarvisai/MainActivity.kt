package com.example.jarvisai

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.regex.Pattern

private val Navy = Color(0xFF050A14)
private val Panel = Color(0xFF0B1728)
private val Cyan = Color(0xFF38DFFF)
private val Pale = Color(0xFFB8F6FF)
private val Muted = Color(0xFF7BA9BB)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

@Composable
private fun JarvisApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("jarvis_store", Context.MODE_PRIVATE) }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("SYSTEM ONLINE") }
    var transcript by remember { mutableStateOf(listOf("JARVIS: Systems online. How may I assist?")) }
    var notes by remember { mutableStateOf(prefs.getStringSet("notes", emptySet())?.toList()?.sorted() ?: emptyList()) }
    var ttsReady by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { result -> ttsReady = result == TextToSpeech.SUCCESS }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            command = spoken
            status = "COMMAND RECEIVED"
        } else status = "READY FOR INPUT"
    }

    fun say(text: String) {
        transcript = (transcript + "JARVIS: $text").takeLast(30)
        status = "SPEAKING"
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${UUID.randomUUID()}")
        status = "SYSTEM ONLINE"
    }

    fun saveNote(note: String) {
        val updated = (prefs.getStringSet("notes", emptySet()) ?: emptySet()).toMutableSet()
        updated.add(note)
        prefs.edit().putStringSet("notes", updated).apply()
        notes = updated.toList().sorted()
    }

    fun setReminder(message: String, minutes: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).putExtra("reminder_text", message)
        val requestCode = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val triggerAt = System.currentTimeMillis() + minutes.coerceAtLeast(1) * 60_000L
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending)
        say("Reminder set for $minutes minute${if (minutes == 1) "" else "s"} from now: $message")
    }

    fun openAppOrSite(raw: String) {
        val target = raw.trim().lowercase(Locale.ROOT)
        try {
            when {
                target.contains("youtube") -> context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
                target.contains("google") -> context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
                target.contains("chatgpt") || target.contains("ai chat") -> context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com")))
                target.contains("whatsapp") -> {
                    val launch = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                    if (launch != null) context.startActivity(launch) else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.whatsapp.com")))
                }
                target.contains("chrome") -> {
                    val launch = context.packageManager.getLaunchIntentForPackage("com.android.chrome")
                    if (launch != null) context.startActivity(launch) else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
                }
                target.contains("camera") -> context.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                target.contains("settings") -> context.startActivity(Intent(Settings.ACTION_SETTINGS))
                target.contains("clock") || target.contains("alarm") -> context.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
                else -> context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw))))
            }
            say("Opening ${raw.removePrefix("open ")}.")
        } catch (_: Exception) { say("I couldn't open that on this phone.") }
    }

    fun process(raw: String) {
        val text = raw.trim()
        val lower = text.lowercase(Locale.ROOT)
        if (text.isBlank()) { say("Please enter a command."); return }
        transcript = (transcript + "YOU: $text").takeLast(30)
        when {
            lower == "hello" || lower.contains("hello jarvis") || lower == "hi" -> say("Hello. JARVIS is online and ready.")
            lower.contains("what time") || lower == "time" || lower.contains("current time") -> say("The time is ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())}.")
            lower.contains("what date") || lower.contains("today's date") || lower == "date" -> say("Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}.")
            lower.startsWith("open ") -> openAppOrSite(lower.removePrefix("open "))
            lower.startsWith("remember that ") || lower.startsWith("remember ") -> {
                val note = text.substringAfter("remember", "").trim().removePrefix("that ").trim()
                if (note.isNotBlank()) { saveNote(note); say("I saved that to your local memory.") } else say("Tell me what you want me to remember.")
            }
            lower.contains("show memory") || lower.contains("what do you remember") || lower.contains("show notes") -> {
                notes = prefs.getStringSet("notes", emptySet())?.toList()?.sorted() ?: emptyList()
                say(if (notes.isEmpty()) "Your memory is empty." else "I have ${notes.size} saved note${if (notes.size == 1) "" else "s"}. They are displayed below.")
            }
            lower.contains("forget all") || lower.contains("clear memory") -> { prefs.edit().remove("notes").apply(); notes = emptyList(); say("Local memory cleared.") }
            lower.startsWith("remind me to ") -> {
                val pattern = Pattern.compile("(?i)^remind me to (.+?) in (\\d+) minutes?$|^remind me to (.+?) in (\\d+) hours?$")
                val matcher = pattern.matcher(text)
                if (matcher.find()) {
                    val message = matcher.group(1) ?: matcher.group(3) ?: "your task"
                    val number = (matcher.group(2) ?: matcher.group(4) ?: "1").toIntOrNull() ?: 1
                    val minutes = if (matcher.group(4) != null) number * 60 else number
                    setReminder(message, minutes.coerceIn(1, 10080))
                } else say("Use this format: remind me to study in 10 minutes, or remind me to call home in 2 hours.")
            }
            lower.contains("help") || lower.contains("what can you do") -> say("Try: open YouTube, open Google, open WhatsApp, open camera, what time is it, remember that my exam is Monday, show memory, or remind me to study in 10 minutes. For open-ended AI chat, tap AI CHAT.")
            else -> say("I don't have a built-in answer for that yet. Tap AI CHAT to open an AI chat service, or say help for commands.")
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Panel, onPrimary = Navy, onBackground = Pale, onSurface = Pale)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("J.A.R.V.I.S.", color = Cyan, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("PERSONAL ASSISTANT // MK-I", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Text("● ONLINE", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                HudCore(Modifier.size(205.dp))
                Text(status, color = Cyan, fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = command,
                    onValueChange = { command = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Enter a command…", color = Muted) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Muted, focusedTextColor = Pale, unfocusedTextColor = Pale, cursorColor = Cyan)
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
                        }
                        try { status = "LISTENING"; speechLauncher.launch(intent) } catch (_: Exception) { say("Speech recognition isn't available. Try typing a command.") }
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)) { Text("🎙 SPEAK", fontWeight = FontWeight.Bold) }
                    Button(onClick = { process(command); command = "" }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16334A), contentColor = Pale)) { Text("RUN COMMAND") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com"))) } catch (_: Exception) { say("Could not open AI chat.") } }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                    Text("✦  OPEN AI CHAT  ·  INTERNET REQUIRED", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("LOCAL MEMORY", color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Text("${notes.size} NOTE(S)", color = Muted, fontSize = 10.sp)
                }
                if (notes.isNotEmpty()) {
                    Text(notes.takeLast(3).joinToString("  •  "), color = Pale, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), maxLines = 2)
                } else Text("Say: ‘remember that …’", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                Spacer(Modifier.height(8.dp))
                Text("ACTIVITY LOG", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp, modifier = Modifier.fillMaxWidth())
                LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f).padding(top = 4.dp)) {
                    items(transcript.takeLast(6).reversed()) { line ->
                        Text(line, color = if (line.startsWith("YOU:")) Pale else Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp))
                    }
                }
                Text("JARVIS AI // PERSONAL BUILD 1.0", color = Color(0xFF34586B), fontSize = 9.sp, letterSpacing = 1.5.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun HudCore(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.shadow(10.dp, CircleShape)) {
        val center = Offset(size.width / 2, size.height / 2)
        val maxR = size.minDimension * 0.47f
        for (i in 0..4) {
            drawCircle(color = Cyan.copy(alpha = if (i == 2) 0.65f else 0.25f), radius = maxR * (0.34f + i * 0.15f), center = center, style = androidx.compose.ui.graphics.drawscope.Stroke(width = if (i == 2) 2.2.dp.toPx() else 1.dp.toPx()))
        }
        for (i in 0 until 48) {
            val angle = Math.toRadians((i * 7.5) - 90.0)
            val inner = maxR * if (i % 4 == 0) 0.78f else 0.86f
            val outer = maxR * 0.94f
            val start = Offset(center.x + kotlin.math.cos(angle).toFloat() * inner, center.y + kotlin.math.sin(angle).toFloat() * inner)
            val end = Offset(center.x + kotlin.math.cos(angle).toFloat() * outer, center.y + kotlin.math.sin(angle).toFloat() * outer)
            drawLine(Cyan.copy(alpha = if (i % 4 == 0) 0.9f else 0.35f), start, end, strokeWidth = if (i % 4 == 0) 2.dp.toPx() else 1.dp.toPx(), cap = StrokeCap.Round)
        }
        drawCircle(color = Cyan.copy(alpha = 0.08f), radius = maxR * 0.48f, center = center)
    }
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("AI", color = Pale, fontSize = 34.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = 7.sp)
            Text("CORE ACTIVE", color = Cyan, fontSize = 8.sp, letterSpacing = 2.sp)
        }
    }
}
